<html>
  <link rel="stylesheet" href="../css/bootstrap.min.css">
<style>
.navbar {
background-color:#00000 ;
font-color : #2F4F4F;
}
</style>
<nav class="navbar navbar-inverse">

  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">KEF Accounting System</a>
    </div>
<ul class="nav navbar-nav">
<li> <a class="active" href="#home"></a>
 <li><a href="../index.html">Home Screen</a></li>
<li><a href="../LOGOUT.php">Log out</a></li>
</ul>
  </div>
</nav>

<div id="email1">
<br><br><br>
<center><bold>Send Alert Via Email ID Its Complasary</bold></center><br><br><br>
<center><form action="message_email.php" method="post"></center>
<br>
<div class="form-group">
					<div class="col-sm-3">
					                    <label for="email" class="col-sm-3 control-label"></label>
					</div>
                    <div class="col-sm-3 ">To:
					<br><br>
						 <select id="level2" class="form-control" name="to">
						  <option value="">None</option>
							<?php
							include('../dbcon.php');
							$getQuery = "select `name`,`email` from `users` ";
							$sql = mysqli_query($conn,$getQuery);
							if($sql)
							{
								while ($getids = mysqli_fetch_array($sql))
								{
									$email = $getids['email'];
									$name = $getids['name'];
									echo "<option value='$email'>$name</option>";
								}
							}
							?>
							</select>
                    <br><br>
				<div class="col-sm-9">
					
					Message:<br><br><textarea rows="4" cols="40" name="msg1"></textarea>
                
<br><br>
<input type="submit" class="btn btn-primary btn-block"></center>
</form>
</div>

</html>