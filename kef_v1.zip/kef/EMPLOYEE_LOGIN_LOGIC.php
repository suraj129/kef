<?php
session_start();
include('dbcon.php');
$name=$_POST["name"];
$password=$_POST["password"];

$sql = "SELECT name, password,role_id FROM users WHERE name = '".$name."' AND password = '".$password."'";
$result = mysqli_query($conn, $sql);
error_reporting(0);
if (mysqli_num_rows($result)>0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result))
	{
        if($name == $row["name"] and $password == $row["password"])
		{
			$_SESSION['employee']=$name;
			$role= $row["role_id"];
			if($role==0)
			header('Location: Employee/EMPLOYEE_DATA_ENTRY.php');
			else if($role==1)
			header('Location: LEVEL 1/LEVEL1_DISPLAY.php');
			else if($role==2)
				header('Location: LEVEL 2/LEVEL2_DISPLAY.php');
					else if($role==3)
				header('Location: LEVEL 3/LEVEL3_DISPLAY.php');
						else if($role==4)
				header('Location: LEVEL 4/LEVEL4_DISPLAY.php');

						else if($role==5)
				header('Location: LEVEL 5/LEVEL5_DISPLAY.php');
			
		}
		else 
		{
			echo "Wrong";
			
		}
    }
	
} 
else
{
    echo "Wrong";
}

mysqli_close($conn);


?>