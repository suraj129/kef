<?php
$checkbox= $_POST['checkbox'];
echo $checkbox;
?>