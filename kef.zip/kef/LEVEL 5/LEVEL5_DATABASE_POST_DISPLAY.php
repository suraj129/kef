
<html>
  <head>
        <title>Level 5 :Post Display</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <link rel="stylesheet" type="text/css" href="../css/default.css"/>
		<script type="text/javascript" src="../js/script.js"></script>
   <link href="css/main.css" rel="stylesheet">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
  <script src="../js/jquery.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>	
<head>

        
  <script src="../js/jquery.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>	
    </head>


<style>
.hline { width:100%; height:1px; background: #fff }

body {
   background-color:#F0F0F0;
   margin: 15px;
   border:1px solid black;
   padding: 5px;
}

 td {
   border: 1px solid black;
   padding: 5px;
   text-align: left;
   font-size: 100%;
    font-weight: bold;
}
table {
    width: 90%;
    border-collapse: collapse;
     font-size: 100%;
    #f5f5f5;
}

th {
    font-size: 15px;
    height: 15px;
    text-align: left;
    border: 1px solid black;
 font-size: 100%;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    left: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s
}

.sidenav a:hover, .offcanvas a:focus{
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}
hr { 
    display: block;
    margin-top: 0.5em;
    margin-bottom: 0.5em;
    margin-left: auto;
    margin-right: auto;
    border-style: inset;
    border-width: 1px;
} 
@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
div {
	 .td {
   border: 1px solid black;
   padding: 5px;
   text-align: left;
   font-size: 100%;
    font-weight: bold;
}
.table {
    width: 90%;
    border-collapse: collapse;
     font-size: 100%;
    #f5f5f5;
}

.th {
    font-size: 15px;
    height: 15px;
    text-align: left;
    border: 1px solid black;
 font-size: 100%;
}

}

</style>

</head>
 
      


<?php
session_start();
include('../dbcon.php');
error_reporting(0);
if(isset($_SESSION['employee'])){
	$bills=0;
$date1 = $_REQUEST['claim_date'];
$employeeno = $_GET["employeeno"];
$sql = mysqli_query($conn,"select `id`,`name` from users where `employee no`='$employeeno'");
while($row1=mysqli_fetch_array($sql))
{
	$id = $row1['id'];
	$user_name = $row1['name'];
	
}
$user = $_SESSION['employee'];
	echo "<center><h5>Kotak Education Foundation,Mumbai</h5>
			<h6>1st Floor North Side,Silk Mills,Sunder Baug,Opp.Deonar Bus Depot,Off.Sion Trombay Road,Deonar,Mumbai-88.</h6></center> ";
			echo "<hr><b><center>For Office Use Only</center></b><left>Date:<input type='text' name='date' style='width: 100px' />
					Cash/cheque:<input type='text' name ='vn' style='width: 100px'/>
					IFT/NEFT:<input type='text' name ='IFT/NEFT' style='width: 100px'/>
					VN:<input type='text' name ='vn' style='width: 80px'/><hr></left> ";	
			
$sql = mysqli_query($conn,"select `employee no`,name from users where name='$user'");
while($row=mysqli_fetch_array($sql))
{
	$empno = $row['employee no'];
	$name = $row['name'];
}
echo "<center><b>Reimbursement of Expenses / Advance Request / Advance Settlement </center></b><hr>";
echo "<left><h5>Name : $user_name</h5></left>";
echo "<left><h5>Date: ".date('d-m-Y', strtotime($date1))."</h5></left>";
echo "<left><h5>Employee no : $employeeno</h5></left>";
$getdetails= mysqli_query($conn,"SELECT `for period`, `Too`, `intervention`, `name of school/center`, `amount recivable/payable`,`having advance`, `fresh advance`, `nett amount receivable`,`empbillcheck`,`bill`,`checkby1`,`approval1`,`approval2`,`approval3`,`approval4` FROM `post` WHERE `user_id`='$id' and`claim_date`='$date1' and`approved`='5'");
if($getdetails)
{
	while($row=mysqli_fetch_array($getdetails))
	{
		$for_period=date("d-m-Y", strtotime($row['for period']));
		$to=date("d-m-Y", strtotime($row['Too']));
		$intervention = $row['intervention'];
		$school = $row['name of school/center'];
		$amount_receivable= $row['amount recivable/payable'];
		$fresh_advance = $row['fresh advance'];
		$nett_amount = $row['nett amount receivable'];
		$having_advance=$row['having advance'];
		$empbillcheck= $row['empbillcheck'];
		$bill=$row['bill'];
		$checkby1 = $row['checkby1'];
		$approval1 = $row['approval1'];
		$approval2 = $row['approval2'];
		$approval3 = $row['approval3'];
		$approval4 = $row['approval4'];
		if($bill=='Yes')
		{
			$bills++;
		}
		
	}
	
	echo "<left><h5>For period : $for_period &nbsp;&nbsp;&nbsp;To : $to &nbsp;&nbsp;&nbsp;</h5><h5>Intervention : $intervention &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h5><h5>Name of school/college : $school</h5></left>";
}
echo "<div style='overflow-x:auto;'><center><table><tr><th><h4><b>Details Of Expenses</b></h4></th><th><h4><b>Amount</b></h4></th></tr>";
$select_query = mysqli_query($conn,"SELECT DISTINCT `cat_id` FROM `post` WHERE `approved`='5' and  `user_id`='$id' and `claim_date`='$date1'");
if ($select_query) {
	# code...
	while ($array_catId = mysqli_fetch_array($select_query)) {
		# code...
		$cat_id = $array_catId['cat_id'];
		$select_amount = mysqli_query($conn,"SELECT SUM(amount) FROM post WHERE cat_id = '$cat_id' AND approved = '5' and `user_id`='$id' and `claim_date`='$date1'");
		$select_categoryname=mysqli_query($conn,"SELECT categories_name from categories where categories_id='$cat_id'");
	if ($select_amount) 
	{
		if($select_categoryname)
		{
			# code...
			while ($array_amount = mysqli_fetch_array($select_amount))
			{
					while($array_name = mysqli_fetch_array($select_categoryname)) 
					{
				
				
				# code...
				$categories_name= $array_name['categories_name'];
				$amount = $array_amount['SUM(amount)'];
				echo "<tr><td>$categories_name</td><td>$amount</td></tr>";

				$amount1=$amount1+$amount;
			}
			
			}
		}
	}else{
			echo "Amount Not Fetched";
		}
	}
	echo "</center>";
	echo "<tr><td><b>Total</td><td>$amount1</td></tr></left>";
echo "<tr><td><b>Amount recivable/payable</td><td>$amount1</left>";
echo "<tr><td>( - )<b>Advance Received</td><td>$having_advance</td></left>";
echo "<tr><td>( + ) <b>Add : Fresh Advance(As per Estimation Attached)</td><td> $fresh_advance</left>";
echo "<tr><td><b>Nett amount Recivable </td><td> $nett_amount</left></table></b>";
echo "</center><hr>";
echo "<left><b>Rs. in words:</b>&nbsp&nbsp&nbsp".convert_number_to_words($nett_amount)."&nbsp &nbsp only</left><br><hr>";
echo "<h5>Prepared by :  $user_name &nbsp&nbsp Check By :$approval1&nbsp Check By :$approval2 &nbsp&nbsp Authorise By :$approval3 $approval4&nbsp</h5><hr>";
if($empbillcheck=='Yes')
				{
				echo "<center><label>&nbsp;&nbsp;&nbsp;<input type='checkbox' id='cbox1' value='Yes' name='bills' checked required='required'>
				<font color='blue'>&nbsp&nbspEmployee Has Attached All The Bills.</center></font></label></h5>";
				}
				echo "<center><table><tr><form action='LEVEL5_UPDATE_POST_APPROVAL.php' method='GET'>";
		if($checkby1=='Yes')
				{
					echo "<input type='checkbox' id='firstName' required='required' value='Yes'  name='checked' autofocus required checked/><font color='red'><b>&nbsp&nbspLevel Has Checked That All The Bills Are Attached.</b></font>";
				}
					echo "<center><b>Total Number Of Attachements : $bills</b></center></tr></table><br>";	
echo "</center> On Account of <br><textarea cols=50></textarea>" ;
echo " <hr>";					
$select_users_posts = mysqli_query($conn,"SELECT p.claim_date,p.id,p.date,p.from,p.to,p.mode,p.remark,p.amount,p.bill,c.categories_name FROM post p,users u,categories c WHERE p.claim_date='$date1' and p.user_id='$id' and u.name='$name' and p.cat_id=c.categories_id and p.approved=5");
		echo "<div style='overflow-x:auto;'><div class='no-print'><div><center><table id='demo' style='width: 90%;border-collapse: collapse;'><tr style=' border: 1px solid black;'><th style='border: 1px solid black;'><h4><b>Expenses</b></h4></th><th style='border: 1px solid black;'><h4><b>Dates</b></h4></th><th style='border: 1px solid black;'><h4><b>Amount</b></h4></th><th style='border: 1px solid black;'><h4><b>Form</b></h4></th><th style='border: 1px solid black;'><h4><b>To</b></h4></th><th style='border: 1px solid black;'><h4><b>Remarks</b></h4></th><th style='border: 1px solid black;'><h4><b>Bill</b></h4></th></tr>";
					
			if($select_users_posts)
			{
				
				
				while($array_get_post_details = mysqli_fetch_array($select_users_posts)){
					$date = date("d-m-Y", strtotime($array_get_post_details['date']));
					$from = $array_get_post_details['from'];
					$to = $array_get_post_details['to'];
					$mode = $array_get_post_details['mode'];
					$remark = $array_get_post_details['remark'];
					$categories_name = $array_get_post_details['categories_name'];
					$id1 = $array_get_post_details['id'];
					$pDate = $array_get_post_details['post_date'];
					$amount= $array_get_post_details['amount'];
					$empbillcheck = $array_get_post_details['empbillcheck'];
					$bil = $array_get_post_details['bill'];
					$total=$total+$amount;
					echo "<tr style='border: 1px solid black;'><td style='border: 1px solid black;'>$categories_name</td><td style='border: 1px solid black;'>$date</td><td style='border: 1px solid black;'>$amount</td><td style='border: 1px solid black;'>$from</td><td style='border: 1px solid black;'>$to</td><td style='border: 1px solid black;'>$remark</td><td>$bil</td></tr>";
			
					}
					echo "<tr style='border: 1px solid black;'><td style='border: 1px solid black;'>Total :</td><td style='border: 1px solid black;'></td><td style='border: 1px solid black;'>$total</td></tr></tr>";
					echo "</center></div></div></div></div></table>";
				echo "<br>";
				
				
				 echo "<input type='hidden' value='$date1' name='claim_date'>
						<button type='submit' name='approved' value='$id' class='btn btn-primary'>Approve</button>
						</tr></form>";
						echo "&nbsp &nbsp &nbsp ";
				echo "<tr><form action='LEVEL5_UPDATE_POST_APPROVAL.php' method='GET'>
				<input type='hidden' value='$date1' name='claim_date'>
					<input type='text' id='feedback' name='feedback' /> &nbsp;&nbsp;
						<button type='submit' name='rejected' value='$id' class='btn btn-primary'>Reject</button>";
					
			}
			echo "	<footer>
			<left>
		<br>
			</footer>";
}
?>

<?php
}
else{
echo 'please log in..';
}
?>
<html>
<style>
@media print
{
    .no-print
    {
        display: none !important;
        height: 0;
    }


    .no-print, .no-print *{
        display: none !important;
        height: 0;
    }
}
</style>
<script>
     
            function printDiv()
            {
              var divToPrint=document.getElementById('demo');
              newWin= window.open("");
              newWin.document.write(divToPrint.outerHTML);
              newWin.print();
              newWin.close();
            }
      
</script>
<div class="no-print">
<input type="button" value="Print First Sheet" onclick="window.print()" class='btn btn-primary'/>
<input type="button" value="Print Second Sheet" onclick="printDiv()" class='btn btn-primary'/>
<button type="button" value="Back" onclick="location.href='LEVEL5_DISPLAY.php'" class='btn btn-primary'>Back</button>
<h5> Design by Trio team</h5>
</div>
</body>

</html>
<?php
function convert_number_to_words($number) {

    $hyphen      = '-';
    $conjunction = ' and ';
    $separator   = ', ';
    $negative    = 'negative ';
    $decimal     = ' point ';
    $dictionary  = array(
        0                   => 'zero',
        1                   => 'one',
        2                   => 'two',
        3                   => 'three',
        4                   => 'four',
        5                   => 'five',
        6                   => 'six',
        7                   => 'seven',
        8                   => 'eight',
        9                   => 'nine',
        10                  => 'ten',
        11                  => 'eleven',
        12                  => 'twelve',
        13                  => 'thirteen',
        14                  => 'fourteen',
        15                  => 'fifteen',
        16                  => 'sixteen',
        17                  => 'seventeen',
        18                  => 'eighteen',
        19                  => 'nineteen',
        20                  => 'twenty',
        30                  => 'thirty',
        40                  => 'fourty',
        50                  => 'fifty',
        60                  => 'sixty',
        70                  => 'seventy',
        80                  => 'eighty',
        90                  => 'ninety',
        100                 => 'hundred',
        1000                => 'thousand',
        1000000             => 'million',
        1000000000          => 'billion',
        1000000000000       => 'trillion',
        1000000000000000    => 'quadrillion',
        1000000000000000000 => 'quintillion'
    );

    if (!is_numeric($number)) {
        return false;
    }

    if (($number >= 0 && (int) $number < 0) || (int) $number < 0 - PHP_INT_MAX) {
        // overflow
        trigger_error(
            'convert_number_to_words only accepts numbers between -' . PHP_INT_MAX . ' and ' . PHP_INT_MAX,
            E_USER_WARNING
        );
        return false;
    }

    if ($number < 0) {
        return $negative . convert_number_to_words(abs($number));
    }

    $string = $fraction = null;

    if (strpos($number, '.') !== false) {
        list($number, $fraction) = explode('.', $number);
    }

    switch (true) {
        case $number < 21:
            $string = $dictionary[$number];
            break;
        case $number < 100:
            $tens   = ((int) ($number / 10)) * 10;
            $units  = $number % 10;
            $string = $dictionary[$tens];
            if ($units) {
                $string .= $hyphen . $dictionary[$units];
            }
            break;
        case $number < 1000:
            $hundreds  = $number / 100;
            $remainder = $number % 100;
            $string = $dictionary[$hundreds] . ' ' . $dictionary[100];
            if ($remainder) {
                $string .= $conjunction . convert_number_to_words($remainder);
            }
            break;
        default:
            $baseUnit = pow(1000, floor(log($number, 1000)));
            $numBaseUnits = (int) ($number / $baseUnit);
            $remainder = $number % $baseUnit;
            $string = convert_number_to_words($numBaseUnits) . ' ' . $dictionary[$baseUnit];
            if ($remainder) {
                $string .= $remainder < 100 ? $conjunction : $separator;
                $string .= convert_number_to_words($remainder);
            }
            break;
    }

    if (null !== $fraction && is_numeric($fraction)) {
        $string .= $decimal;
        $words = array();
        foreach (str_split((string) $fraction) as $number) {
            $words[] = $dictionary[$number];
        }
        $string .= implode(' ', $words);
    }

    return $string;
}

?>
</html>