<?php
session_start();
include('../dbcon.php');
error_reporting(0);
if(isset($_SESSION['employee'])){
	$bills=0;
$date1 = $_REQUEST['claim_date'];
$employeeno = $_GET["employeeno"];
$sql = mysqli_query($conn,"select `id`,`name` from users where `employee no`='$employeeno'");
while($row1=mysqli_fetch_array($sql))
{
	$id = $row1['id'];
	$user_name = $row1['name'];
	
}
$sql = mysqli_query($conn,"delete from `post` where user_id='$id' and claim_date='$date1' and approved='5'");
if($sql)
{
	header('Location:LEVEL5_DATABASE_POST_APPROVED.php');
}
}
else{
echo 'please log in..';
}
?>