  <?php 
	 $name=$_POST["name"];
	 $password=$_POST["password"];
     $to = $_POST["email"];
     $from = 'Kotak Education Foundation@me.org';
     $subject = ' Eamil Alert';
     $message = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"     "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
                <html xmlns="http://www.w3.org/1999/xhtml">
                <head>
                <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
                <title>Login : Dtails</title>
                </head>

                <body>
                <div style="width:400px; height:400px; background-color:#FAEBD7; color:#A52A2A">
                <h1>This is an alert Meassage for your login information.</h1>
                <p>User name:$name <br>User Password:$password <br>
<center>              PLEASE CHECK YOURS AUTO ACCOUNTING SYSTEM SYSTEM WEB TEMPLATE.</center>
		<center>link-  kef2016-17.eys.es		</center>	
                </div>
                </body>
                </html>';
    $headers = "From: $from\n";
    $headers .= "MIME-Version: 1.0\n";
    $headers .= "Content-type: text/html; charset=iso-8859-1\n";
    if(mail($to, $subject, $message, $headers)){
        echo 'Mail was sent';
    }
    else{
        echo 'Error in sending' ;
    }

?>
<html>
<style>
.button {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}
</style><br>
<a href="EMPLOYEE_SIGNUP.php" class="button">Sucessfully Email is Sent</a>
</html>