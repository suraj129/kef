<?php
session_start();
if(isset($_SESSION['admin'])){
?>

<html>
  <head>
        <title>LEVEL AMOUNT</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <link rel="stylesheet" type="text/css" href="../css/default.css"/>
		<script type="text/javascript" src="../js/script.js"></script>
   <link href="css/main.css" rel="stylesheet">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>	
  <style>


</style> 
</head>
<body>
<nav class="navbar navbar-inverse">

  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="EMPLOYEE_LOGIN.php">KEF Accounting System</a>
    </div>
	<ul class="nav navbar-nav">
<li> <a class="active" href="#home"></a>
 <li><a href="EMPLOYEE_SIGNUP.php">Home Screen</a></li>
<li><a href="EMPLOYEE_DELETE.php">Delete Employee</a></li>
<li><a href="../message/email.html">Sent a Alert</a></li>
<li><a href="MODIFY_EMPLOYEE.php">Modify Employee</a></li>
<li><a href="LEVEL_AMOUNT_CHANGE.php">Change Level Amount</a></li>
<li><a href="ADMIN_LOGOUT.php">Log out</a></li>
</ul>
  </div>
</nav>
<div class="container">
            <form class="form-horizontal" role="form" action="LEVEL_AMOUNT_CHANGE_LOGIC.php" method="post">
							<h1 align="center">Change Amount Of Level</h1><br>
               
				<div class="form-group">
                    <label for="password" class="col-sm-3 control-label">Change Amount</label>
					
                    <div class="col-sm-9">
                        <input type="number" id="number" placeholder="Enter Amount" class="form-control" name="amount">
                    </div>
				
                 <!-- /form -->
        </div> 
		
		<div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit" class="btn btn-primary btn-block">Submit</button>
                    </div>
                </div>
            </form><!-- ./container -->
			</div>
		</body>
		</html>
				
				
}


}

</body>
	<?php
}
else{
echo 'please log in..';

}
?>
</html>