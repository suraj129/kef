<?php
session_start();
include('dbcon.php');
$name=$_POST["name"];
$password=$_POST["password"];

$sql = "SELECT name, password FROM admin WHERE name = '".$name."' AND password = '".$password."'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        if($name == $row["name"] and $password == $row["password"]){
			$_SESSION['admin']=$name;
		
			header('Location: EMPLOYEE_SIGNUP.php');
			
		}
		else {
			echo "Wrong";
			
		}
    }
	
} else
{
   header('Location:ADMIN_LOGIN.php');
}

mysqli_close($conn);


?>