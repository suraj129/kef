<?php
include('../dbcon.php');
$id = $_GET["view"];
$getdetails = "select * from users where id='$id'";
$query =  mysqli_query($conn,$getdetails);
if($query)
{
	while($getdata = mysqli_fetch_array($query))
	{
		$name = $getdata['name'];
		$employeeno = $getdata['employee no'];
		$password = $getdata['password'];
		$email = $getdata['email'];
		echo $name;
		echo "<br>";
		echo $employeeno;
		echo "<br>";
		echo $password;
		echo "<br>";
		echo $email;
	}
}
?>