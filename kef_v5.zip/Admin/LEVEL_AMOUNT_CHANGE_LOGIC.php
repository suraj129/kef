<html>
  <head>
        <title>LEVEL AMOUNT</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <link rel="stylesheet" type="text/css" href="../css/default.css"/>
		<script type="text/javascript" src="../js/script.js"></script>
   <link href="css/main.css" rel="stylesheet">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>	
  <style>


</style> 
</head>
<body>
<nav class="navbar navbar-inverse">

  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="EMPLOYEE_LOGIN.php">KEF Accounting System</a>
    </div>
	<ul class="nav navbar-nav">
<li> <a class="active" href="#home"></a>
 <li><a href="EMPLOYEE_SIGNUP.php">Home Screen</a></li>
<li><a href="EMPLOYEE_DELETE.php">Delete Employee</a></li>
<li><a href="../message/email.html">Sent a Alert</a></li>
<li><a href="MODIFY_EMPLOYEE.php">Modify Employee</a></li>
<li><a href="LEVEL_AMOUNT_CHANGE.php">Change Level Amount</a></li>
<li><a href="ADMIN_LOGOUT.php">Log out</a></li>
</ul>
  </div>
</nav>
<div class="container">
<?php
include('dbcon.php');
session_start();
if(isset($_SESSION['admin'])){
	$amount = $_POST['amount'];
	$sql = mysqli_query($conn,"update level_amount set amount='$amount'");
	if($sql)
		echo "<h3>Amount is Updated.<h3>";
?>
<?php
}
else{
echo 'please log in..';

}
?>