<html>
  <head>
        <title>Changed password</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <link rel="stylesheet" type="text/css" href="../css/default.css"/>
		<script type="text/javascript" src="../js/script.js"></script>
   <link href="css/main.css" rel="stylesheet">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>	
  <style>
body {
    margin: 0;
}

</style>  
    </head>
    <body>
<nav class="navbar navbar-inverse">

  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">KEF Accounting System</a>
    </div>
<ul class="nav navbar-nav">
<li> <a class="" href=""></a>

<li><a href="LOGOUT.php">Log out</a></li>
</ul>
  </div>
</nav>

<div style="margin-left:18%;padding:1px 0px;height:1000px;">
<center><h3>Kotak Education Foundation,Mumbai</h3>
<h4>1st Floor North Side,Silk Mills,Sunder Baug,Opp.Deonar Bus Depot,Off.Sion Trombay Road,Deonar.</h4>
<h4>Mumbai-88.</h4>
<br></center>
	<div class="container">
</div>
</html>


<?php
include('dbcon.php');
session_start();
error_reporting(0);
if(isset($_SESSION['employee']))
{

$name = $_SESSION['employee'];
$password=$_POST["password"];

$sql = "UPDATE `users` SET `password`='$password' WHERE name='$name'";
$result = mysqli_query($conn, $sql);
if($result)
{

	echo"<h3>Your Password is Changed.</h3><h3>You need To log out.</h3>";
}

else{
	echo "<h3>Your Password is not changed.</h3>";
}
}
else{
echo "please log in..";

}
?>
