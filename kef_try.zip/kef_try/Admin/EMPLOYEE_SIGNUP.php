<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<?php
session_start();
if(isset($_SESSION['admin'])){
?>
  <head>
        <title>Admin : Emoloyee add</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <link rel="stylesheet" type="text/css" href="../css/default.css"/>
		<script type="text/javascript" src="../js/script.js"></script>
   <link href="css/main.css" rel="stylesheet">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
  <script src="../js/jquery.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>	


        
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>	
  <style>
body {
    margin: 0;
}


</style>  
    </head>
    <body>

<nav class="navbar navbar-inverse">

  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">KEF Accounting System</a>
    </div>
<ul class="nav navbar-nav">
<li> <a class="active" href="#home"></a>
 <li><a href="EMPLOYEE_SIGNUP.php">Home Screen</a></li>
<li><a href="EMPLOYEE_DELETE.php">Delete Employee</a></li>
<li><a href="../message/email.html">Sent a Alert</a></li>
<li><a href="MODIFY_EMPLOYEE.php">Modify Employee</a></li>
<li><a href="LEVEL_AMOUNT_CHANGE.php">Change Level Amount</a></li>
<li><a href="data/test.html">Back Up Data</a></li>
 <li><a href="../contactus.html">Contact Us</a></li>
 <li><a href="../aboutus.html">About Us</a></li>
 <li><a href="https://sqlizer.io/">Import Data</a></li>
  <li><a href="ADMIN_LOGOUT.php">Log out</a></li>
 </ul>
  </div>
</nav>
     <link href="css/main.css" rel="stylesheet">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
<body>
	<div class="container">
<body>
<br>
<div class="container">
            <form class="form-horizontal" role="form" action="EMPLOYEE_SIGNUP_LOGIC.php" method="post">
                <h1>Employee Registration Form</h1><br>
                <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Full Name</label>
                    <div class="col-sm-9">
                        <input type="text" id="firstName" placeholder="Name" class="form-control" name="name"autofocus>
                        
                    </div>
                </div>
				<div class="form-group">
                    <label for="password" class="col-sm-3 control-label">Password</label>
                    <div class="col-sm-9">
                        <input type="password" id="password" placeholder="Password" class="form-control" name="password">
                    </div>
                </div>
				<div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Employee No:</label>
                    <div class="col-sm-9">
                        <input type="number" id="email" placeholder="Employee no" class="form-control" name="employeeno">
                    </div>
                </div>
				<div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Starting Level</label>
                    <div class="col-sm-9">
						 <select id="role" class="form-control" name="stlevel">
							<option value="none">None</option>
                            <option value="0">Level 1</option>
                            <option value="1">Level 2 </option>
                            <option value="2">Level 3</option>
                            <option value="3">Level 4</option>
				<option value="4">Level 5</option>
                        </select>
                    </div>
                </div>
				<div class="form-group">
                    <label for="email" class="col-sm-3 control-label"> Level 1 Approval</label>
                    <div class="col-sm-9">
						 <select id="level1" class="form-control" name="level1">
						 <option value="">None</option>
							<?php
							include('../dbcon.php');
							$getQuery = "select `name`,`employee no` from users where role_id ='1' ";
							$sql = mysqli_query($conn,$getQuery);
							if($sql)
							{
								while ($getids = mysqli_fetch_array($sql))
								{
									$id = $getids['employee no'];
									$name = $getids['name'];
									echo "<option value='$id'>$name</option>";
								}
							}
							?>
							</select>
                    </div>
					
                </div>
				<div class="form-group">
                    <label for="email" class="col-sm-3 control-label"> Level 2 Approval</label>
                    <div class="col-sm-9">
						 <select id="level2" class="form-control" name="level2">
						  <option value="">None</option>
							<?php
							include('dbcon.php');
							$getQuery = "select `name`,`employee no` from users where role_id ='2' ";
							$sql = mysqli_query($conn,$getQuery);
							if($sql)
							{
								while ($getids = mysqli_fetch_array($sql))
								{
									$id = $getids['employee no'];
									$name = $getids['name'];
									echo "<option value='$id'>$name</option>";
								}
							}
							?>
							</select>
                    </div>
				
					
                </div>
					<div class="form-group">
                    <label for="email" class="col-sm-3 control-label"> Level 3 Approval</label>
                    <div class="col-sm-9">
						 <select id="level3" class="form-control" name="level3">
						  <option value="">None</option>
							<?php
							include('dbcon.php');
							$getQuery = "select `name`,`employee no` from users where role_id ='3' ";
							$sql = mysqli_query($conn,$getQuery);
							if($sql)
							{
								while ($getids = mysqli_fetch_array($sql))
								{
									$id = $getids['employee no'];
									$name = $getids['name'];
									echo $id;
									echo $name;
									echo "<option value='$id'>$name</option>";
								}
							}
							?>
							</select>
                    </div>
					</div>
				<div class="form-group">
                    <label for="email" class="col-sm-3 control-label"> Level 4 Approval</label>
                    <div class="col-sm-9">
						 <select id="level4" class="form-control" name="level4">
						  <option value="">None</option>
							<?php
							include('dbcon.php');
							$getQuery = "select `name`,`employee no` from users where role_id ='4' ";
							$sql = mysqli_query($conn,$getQuery);
							if($sql)
							{
								while ($getids = mysqli_fetch_array($sql))
								{
									$id = $getids['employee no'];
									$name = $getids['name'];
									echo "<option value='$id'>$name</option>";
								}
							}
							?>
							</select>
                    </div>
					
                </div>
               	<div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Level 5 Approval</label>
                    <div class="col-sm-9">
						 <select id="level5" class="form-control" name="level5">
						  <option value="">None</option>
							<?php
							include('dbcon.php');
							$getQuery = "select `name`,`employee no` from users where role_id ='5' ";
							$sql = mysqli_query($conn,$getQuery);
							if($sql)
							{
								while ($getids = mysqli_fetch_array($sql))
								{
									$id = $getids['employee no'];
									$name = $getids['name'];
									echo "<option value='$id'>$name</option>";
								}
							}
							?>
							</select>
                    </div>
					</div>
				<div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Email</label>
                    <div class="col-sm-9">
                        <input type="email" id="email" placeholder="Email" class="form-control" name="email">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="country" class="col-sm-3 control-label">ROLE</label>
                    <div class="col-sm-9">
                        <select id="role" class="form-control" name="role">
                            <option value="0">Employee</option>
                            <option value="1">Level 1 </option>
                            <option value="2">Level 2</option>
                            <option value="3">Level 3</option>
                            <option value="4">Level 4</option>
							<option value="5">Level 5</option>
                        </select>
                    </div>

   
                 <!-- /form -->
        </div> 
		 
		<div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit" class="btn btn-primary btn-block">Register</button>
						
                    </div>
                </div>
            </form>
			<footer>
			<center>
			<h5> Design by Trio team</h5>
			</footer>
		</body>
		<?php
}
else{
echo 'please log in..';

}
?>
		</html>