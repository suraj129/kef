<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "KEF_ACCOUNTING";




// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
	echo "<img src='images/2222.png'></img> Connection Failed </br>";
}

?>
