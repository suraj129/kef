<?php

session_start();
if(isset($_SESSION['employee']))
{
include('../dbcon.php');
error_reporting(0);
$id= $_GET['id'];
$sql = mysqli_query($conn,"select email from users where id='$id'");
while($row=mysqli_fetch_array($sql))
{
	$to = $row['email'];
}
require '../PHPMailer/PHPMailerAutoload.php';
$mail = new PHPMailer;

$mail->isSMTP();                                   // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com';                    // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                            // Enable SMTP authentication
$mail->Username = 'donotreply@kotakeducationfoundation.org';          // SMTP username
$mail->Password = 'donotreply@123'; // SMTP password
$mail->SMTPSecure = 'tls';                         // Enable TLS encryption, `ssl` also accepted
$mail->Port = 587;                                 // TCP port to connect to

$mail->setFrom('email@codexworld.com', '');
$mail->addReplyTo('email@codexworld.com', '');
$mail->addAddress($to);   // Add a recipient
//$mail->addCC('cc@example.com');
//$mail->addBCC('bcc@example.com');

$mail->isHTML(true);  // Set email format to HTML


$bodyContent ='Your Claimed Expenses Is approved By the Level.<br>Submit the Voucher Printout To Accounts Department.<br>Please Kindley Check it .<br>Go to: https://192.168.0.30/kef/';
$bodyContent .= '<p>This is the Auto Mailing From The Kotak Education Foundation System Do Not Give Reply';

$mail->Subject = 'Email from Kotak Education Foundation';
$mail->Body    = $bodyContent;

if(!$mail->send()) {
    echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
	header('Location:LEVEL3_DISPLAY.php');
}


}
else{
echo 'please log in..';

}
?>