<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

  <head>
        <title>Employee Data Entry Form</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <link rel="stylesheet" type="text/css" href="../css/default.css"/>
		<script type="text/javascript" src="../js/script.js"></script>
   <link href="css/main.css" rel="stylesheet">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
  <script src="../js/jquery.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>	
  <style>
body {
    margin: 0;
}

ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    width: 18%;
    background-color: #f1f1f1;
    position: fixed;
    height: 100%;
    overflow: auto;
}

li a {
    display: block;
    color: #000;
    padding: 8px 16px;
    text-decoration: none;
}

li a.active {
    background-color: blue;
    color: white;
}

li a:hover:not(.active) {
    background-color: #555;
    color: white;
}
</style>  
    </head>
    <body>

        <title>Employee Data Entry Form</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <link rel="stylesheet" type="text/css" href="../css/default.css"/>
		<script type="text/javascript" src="../js/script.js"></script>
   <link href="css/main.css" rel="stylesheet">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>	
  <style>
body {
    margin: 0;
}

ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    width: 18%;
    background-color: #f1f1f1;
    position: fixed;
    height: 100%;
    overflow: auto;
}

li a {
    display: block;
    color: #000;
    padding: 8px 16px;
    text-decoration: none;
}

li a.active {
    background-color: blue;
    color: white;
}

li a:hover:not(.active) {
    background-color: #555;
    color: white;
}
</style>  
    </head>
    <body>
	<ul>
  <li><a class="active" href="#home">KEF Accounting System</a></li>
  <li><a href="#news">Home Screen</a></li>
    <li><a href="EMPLOYEE_DELETE.php">Delete Employee</a></li>
	   <li><a href="UPDATE_EMPLOYEE.php">Update Employee</a></li>
    <li><a href="ADMIN_LOGOUT.php">Log out</a></li>
	 <li><a href="aboutus.html">About Us</a></li>
	   <li><a href="contact.html">Contact Us</a></li>
</ul>
     <link href="css/main.css" rel="stylesheet">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
<body><center><h3>Kotak Education Foundation,Mumbai</h3>
<h4>1st Floor North Side,Silk Mills,Sunder Baug,Opp.Deonar Bus Depot,Off.Sion Trombay Road,Deonar.</h4>
<h4>Mumbai-88.</h4>
<br></center>
	<div class="container">
<body>

<div class="container">
            <form class="form-horizontal" role="form" action="EMPLOYEE_SIGNUP_LOGIC.php" method="post">
                <h1>Employee Registration Form</h1><br>
		                <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Full Name</label>
                    <div class="col-sm-9">
                        <input type="text" id="firstName" placeholder="Name" class="form-control" name="name"autofocus required>
                        
                    </div>
                </div>
				<div class="form-group">
                    <label for="password" class="col-sm-3 control-label">Password</label>
                    <div class="col-sm-9">
                        <input type="password" id="password" placeholder="Password" class="form-control" name="password" required>
                    </div>
                </div>
				<div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Employee No:</label>
                    <div class="col-sm-9">
                        <input type="number" id="email" placeholder="Employee no" class="form-control" name="employeeno" required>
                    </div>
                </div>
				<div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Phone</label>
                    <div class="col-sm-9">
                        <input type="number" id="email" placeholder="Phone" class="form-control" name="phone">
                    </div>

                </div>

				<div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Email</label>
                    <div class="col-sm-9">
                        <input type="email" id="email" placeholder="Email" class="form-control" name="email" required>
                    </div>
                </div>
                
        		        <div class="form-group">
                    <label for="country" class="col-sm-3 control-label">ROLE</label>
                    <div class="col-sm-9">
                        <select id="role" class="form-control" name="role">
                            <option value="0">Employee</option>
                            <option value="1">Level 1 </option>
                            <option value="2">Level 2</option>
                            <option value="3">Level 3</option>
                            <option value="4">Level  4</option>
                        </select>
                    </div>
	</div>
				<div class="form-group">
					<label class="col-sm-4 control-label">level approvals:</label>
					 <div class="col-sm-8">
					<input type="checkbox" name = "levels[]" value="1"> level 1 </br>
					<input type="checkbox" name="levels[]" value="2"> level 2 </br>
					<input type="checkbox" name="levels[]" value="3"> leevel 3 </br>

					</div>
					</div>
	  
                 <!-- /form -->
		<div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit" class="btn btn-primary btn-block">Register</button>
						
                    </div>
                </div>
            </form>
			<footer>
			<center>
			<h5> Design by <a href="contact.html">Trio team</h5><h5></h5>
			</footer>
		</body>
		</html>