function addRow(tableID) {
	var table = document.getElementById(tableID);
	var rowCount = table.columns.length;
	if(rowCount <=19){							// limit the user from creating fields more than your limits
		var row = table.insertColumn(rowCount);
		var colCount = table.columns[0].cells.length;
		for(var i=0; i<colCount; i++) {
			var newcell = row.insertCell(i);
			newcell.innerHTML = table.columns[0].cells[i].innerHTML;
		}
	}else{
		 alert("Maximum Expenses is 19");
			   
	}
}