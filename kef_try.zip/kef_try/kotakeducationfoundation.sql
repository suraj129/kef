-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 20, 2017 at 12:45 PM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kotakeducationfoundation`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `name` varchar(12) NOT NULL,
  `password` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`name`, `password`) VALUES
('admin', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `categories_id` int(11) NOT NULL,
  `categories_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`categories_id`, `categories_name`) VALUES
(1, 'Conveyance expenses'),
(2, 'Inconvinece Allowance'),
(3, 'Refreshment charges'),
(4, 'Repair and maintance Charges'),
(5, 'Housekeeping material'),
(6, 'Housekeeping Wages'),
(7, 'Advertisement expenses'),
(8, 'Printing and stationery Expenses'),
(9, ' Remib. Medical Expenses(Salary-Monthly Expenses)'),
(10, 'Photo Expenses'),
(11, 'Honorarium Given'),
(12, 'Internet Expenses'),
(13, 'Electricity Charges'),
(14, 'Hire Charges'),
(15, 'Flower Expenses'),
(16, 'Telephone Expenses'),
(17, 'Postage & Courier Expenses'),
(18, 'Gifts Expenses'),
(19, 'Miscellaneous Expenses');

-- --------------------------------------------------------

--
-- Table structure for table `checkbox`
--

CREATE TABLE `checkbox` (
  `checkbox` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `checkbox`
--

INSERT INTO `checkbox` (`checkbox`) VALUES
('Male'),
('jj');

-- --------------------------------------------------------

--
-- Table structure for table `level_amount`
--

CREATE TABLE `level_amount` (
  `amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `level_amount`
--

INSERT INTO `level_amount` (`amount`) VALUES
(5000);

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `id` int(11) NOT NULL,
  `date` varchar(10) NOT NULL,
  `amount` int(10) NOT NULL,
  `from` varchar(20) NOT NULL,
  `to` varchar(20) NOT NULL,
  `mode` varchar(255) NOT NULL,
  `remark` varchar(255) NOT NULL,
  `cat_id` int(2) NOT NULL,
  `bill` varchar(3) NOT NULL,
  `empbillcheck` varchar(10) NOT NULL,
  `checkby1` varchar(10) NOT NULL,
  `user_id` int(12) NOT NULL,
  `claim_date` date NOT NULL,
  `for period` varchar(30) NOT NULL,
  `Too` varchar(30) NOT NULL,
  `intervention` varchar(50) NOT NULL,
  `name of school/center` varchar(50) NOT NULL,
  `amount recivable/payable` int(11) NOT NULL,
  `having advance` int(10) NOT NULL,
  `fresh advance` int(11) NOT NULL,
  `nett amount receivable` int(11) NOT NULL,
  `approved` int(11) NOT NULL DEFAULT '-2',
  `rejected` varchar(300) NOT NULL,
  `rejectedby` varchar(100) NOT NULL,
  `approval1` varchar(30) NOT NULL,
  `approval2` varchar(30) NOT NULL,
  `approval3` varchar(30) NOT NULL,
  `approval4` varchar(30) NOT NULL,
  `approval5` varchar(30) NOT NULL,
  `level1` int(20) NOT NULL,
  `level2` int(20) NOT NULL,
  `level3` int(20) NOT NULL,
  `level4` int(20) NOT NULL,
  `level5` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `role_id` int(11) NOT NULL,
  `role_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`role_id`, `role_name`) VALUES
(0, 'Employee'),
(1, 'Level 1'),
(2, 'Level 2'),
(3, 'Level 3'),
(4, 'Level 4'),
(5, 'level5');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `employee no` int(11) NOT NULL,
  `password` varchar(10) NOT NULL,
  `stlevel` int(2) NOT NULL,
  `email` varchar(50) NOT NULL,
  `role_id` int(20) NOT NULL,
  `level1` int(11) NOT NULL,
  `level2` int(11) NOT NULL,
  `level3` int(11) NOT NULL,
  `level4` int(11) NOT NULL,
  `level5` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `employee no`, `password`, `stlevel`, `email`, `role_id`, `level1`, `level2`, `level3`, `level4`, `level5`) VALUES
(33, 'KEFROLE', 0, '123', 4, 'dhiren.g@somaiya.edu', 5, 0, 0, 0, 0, 0),
(36, 'Rekha Narayan', 10000, '123', 4, 'dhiren.g@somaiya.edu', 4, 0, 0, 0, 0, 0),
(37, 'Arokia Marry Chettiar', 627, '123', 3, 'dhiren.g@somaiya.edu', 3, 0, 0, 0, 10000, 0),
(38, 'Shilpa Dayanand Bhure', 625, '123', 2, 'dhiren.g@somaiya.edu', 2, 0, 0, 627, 10000, 0),
(39, 'Mohini Ganpat Chavan', 557, '123', 1, 'dhiren.g@somaiya.edu', 1, 0, 625, 627, 10000, 0),
(40, 'Trupti Sachin Lalya', 693, '123', 1, 'dhiren.g@somaiya.edu', 1, 0, 625, 627, 10000, 0),
(41, 'Vedavati Gajielappa Khade', 545, '123', 0, 'dhiren.g@somaiya.edu', 0, 557, 625, 627, 10000, 0),
(42, 'Appa Sonawane', 655, '123', 0, 'dhiren.g@somaiya.edu', 0, 557, 625, 627, 10000, 0),
(43, 'Vaibhav Naikade', 41, '123', 3, 'dhiren.g@somaiya.edu', 3, 0, 0, 0, 10000, 0),
(44, 'Pooja Ashok Surve', 296, '123', 2, 'dhiren.g@somaiya.edu', 0, 0, 0, 41, 10000, 0),
(45, 'Riya Prashant Raikar', 681, '123', 2, 'dhiren.g@somaiya.edu', 0, 0, 0, 41, 10000, 0),
(46, 'Nitesh Bapurao Chavan', 715, '123', 0, 'dhiren.g@somaiya.edu', 0, 693, 625, 627, 10000, 0),
(47, 'Akshata Rajendra Shedge', 684, '123', 0, 'dhiren.g@somaiya.edu', 0, 557, 625, 627, 10000, 0),
(48, 'Maya Patil', 656, '123', 0, 'dhiren.g@somaiya.edu', 0, 557, 625, 627, 10000, 0),
(49, 'Manasi Milind Gokhale', 740, '123', 0, 'dhiren.g@somaiya.edu', 0, 557, 625, 627, 10000, 0),
(50, 'Padmaja Gangadhar Kadam', 385, '123', 0, 'dhiren.g@somaiya.edu', 0, 557, 625, 627, 10000, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`categories_id`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id`),
  ADD KEY `f` (`user_id`),
  ADD KEY `fk123` (`cat_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`role_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD UNIQUE KEY `employee no` (`employee no`),
  ADD KEY `fk` (`role_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `categories_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `post`
--
ALTER TABLE `post`
  ADD CONSTRAINT `f` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `post_ibfk_1` FOREIGN KEY (`cat_id`) REFERENCES `categories` (`categories_id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
