<?php
session_start();
if(isset($_SESSION['level4'])){
?>
    <head>

      
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <link rel="stylesheet" type="text/css" href="../css/default.css"/>
		<script type="text/javascript" src="../js/script.js"></script>
   <link href="css/main.css" rel="stylesheet">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
  <script src="../js/jquery.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>	
     <title>Level 4:Display</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <link rel="stylesheet" type="text/css" href="../css/default.css"/>
		<script type="text/javascript" src="../js/script.js"></script>
   <link href="css/main.css" rel="stylesheet">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>	
  <style>
 body {
	 
	height:100%;
	font-family: 'Open Sans', sans-serif;
	background: #092756;
	background: -moz-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%),-moz-linear-gradient(top,  rgba(57,173,219,.25) 0%, rgba(42,60,87,.4) 100%), -moz-linear-gradient(-45deg,  #670d10 0%, #092756 100%);
	background: -webkit-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%), -webkit-linear-gradient(top,  rgba(57,173,219,.25) 0%,rgba(42,60,87,.4) 100%), -webkit-linear-gradient(-45deg,  #670d10 0%,#092756 100%);
	background: -o-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%), -o-linear-gradient(top,  rgba(57,173,219,.25) 0%,rgba(42,60,87,.4) 100%), -o-linear-gradient(-45deg,  #670d10 0%,#092756 100%);
	background: -ms-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%), -ms-linear-gradient(top,  rgba(57,173,219,.25) 0%,rgba(42,60,87,.4) 100%), -ms-linear-gradient(-45deg,  #670d10 0%,#092756 100%);
	background: -webkit-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%), linear-gradient(to bottom,  rgba(57,173,219,.25) 0%,rgba(42,60,87,.4) 100%), linear-gradient(135deg,  #670d10 0%,#092756 100%);
	filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#3E1D6D', endColorstr='#092756',GradientType=1 );
}
.navbar{
  background:transparent;
  background-image:none;
  border-color:transparent;
  box-shadow:none;
}
h2,h4,h5,h1,h3,label{ color: #fff; text-shadow: 0 0 10px rgba(0,0,0,0.3); letter-spacing:1px; 
input[type=number]::-webkit-inner-spin-button { 
    -webkit-appearance: none;
    cursor:pointer;
    display:block;
    width:8px;
    color: #333;
    text-align:center;
    position:relative;
}
</style>  
    </head>
    <body>
<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">KEF Accounting System</a>   
	<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button></div>
	  <div class="collapse navbar-collapse" id="myNavbar">
	  <ul class="nav navbar-nav">
<li> <a class="" href="#home"></a>
 <li><a href="LEVEL4_DISPLAY.php">Home Screen</a></li>
<li><a href="LEVEL4_CLAIM_EXPENSES.php">Claim Expenses</a></li>
<li><a href="LEVEL4_REJECTED_POST.php">Inbox</a></li>
<li><a href="EMPLOYEE_CHANGE_PASSWORD.php">Change Password</a></li>
<li><a href="LEVEL4_TOPSHEET_PRINT.php">PRINT</a></li>
<li><a href="LEVEL4_DATA_ENTRY.php">Data Entry</a></li>
<li><a href="POST_REJECTED.php">Rejected Post</a></li>
 <li><a href="../contactus.html">Contact Us</a></li>
 <li><a href="../aboutus.html">About Us</a></li>
<li><a href="../LOGOUT.php">Log out</a></li>
</ul>
  </div>
  </div>
</nav>

<div style="">
	
	<div class="container">

<?php
	include('../dbcon.php');
	$username= $_SESSION['level4'];
$getlevel= mysqli_query($conn,"select `employee no` from users where name='$username'");
if($getlevel)
{
while($row = mysqli_fetch_array($getlevel))
{
	$phone=$row['employee no'];
}
}
	$select_post_per_users = mysqli_query($conn,"SELECT DISTINCT name FROM users u,post p WHERE u.id=p.user_id and p.level4='$phone' and p.approved='3'");
	
	if($select_post_per_users){
		
			echo "<br><br><hr width='90%'><br>";
		echo "<h3>Level 4 Expenses Approvals:</h3>";
	
		while($array_get_users = mysqli_fetch_array($select_post_per_users)){
			$user_name = $array_get_users['name'];
					
			echo "<h4>Name Of Employee  :     $user_name</h4>";
			echo "<input type='hidden' name='username' value='$user_name'>";
			echo "&nbsp &nbsp &nbsp<form action='LEVEL4_POST_APPROVED.php' method='get'>
					<button type='submit' value='$user_name' name='username' class='btn btn-primary'>View Expenses</button>
					</tr>
					</table>
				</form>";
			
		}
	}else{
		echo "Data Retriving Error";
	}
?>
</div>

</html>
		<?php
}
else{
echo 'please log in..';

}
?>
</html>