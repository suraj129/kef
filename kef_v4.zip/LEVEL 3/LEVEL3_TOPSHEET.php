	<?php
include('../dbcon.php');
session_start();
if(isset($_SESSION['level3'])){
error_reporting(0);
?>
<html>
  <head>
        <title>LEVEL3 :Topsheet</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <link rel="stylesheet" type="text/css" href="../css/default.css"/>
		<script type="text/javascript" src="../js/script.js"></script>
   <link href="css/main.css" rel="stylesheet">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
  <script src="../js/jquery.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>	
  <style>
<title> Sheet</title>
<style>
input[type=number]::-webkit-inner-spin-button { 
    -webkit-appearance: none;
    cursor:pointer;
    display:block;
    width:8px;
    color: #333;
    text-align:center;
    position:relative;
}

input[type=number]::-webkit-inner-spin-button:before,
input[type=number]::-webkit-inner-spin-button:after {
    content: "^";
    position:absolute;
    right: 0;
    font-family:monospace;
    line-height:
}

input[type=number]::-webkit-inner-spin-button:before {
    top:0px;
}

input[type=number]::-webkit-inner-spin-button:after {
    bottom:0px;
    -webkit-transform: rotate(180deg);
}
body {
   background-color:#F0F0F0;
}

 td {
   border: 1px solid black;
   padding: 5px;
   text-align: left;
   font-size: 100%;
    font-weight: bold;
}
table {
    width: 90%;
    border-collapse: collapse;
     font-size: 100%;
    #f5f5f5;
}

th {
    font-size: 15px;
    height: 15px;
    text-align: left;
    border: 1px solid black;
 font-size: 100%;
}
@media print
{
    #pager,
    form,
    .no-print
    {
        display: none !important;
        height: 0;
    }


    .no-print, .no-print *{
        display: none !important;
        height: 0;
    }
}
.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    left: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s
}

.sidenav a:hover, .offcanvas a:focus{
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>
</html>

<?php
echo "<center><h5>Kotak Education Foundation,Mumbai</h5>";
			echo "<h6>1st Floor North Side,Silk Mills,Sunder Baug,Opp.Deonar Bus Depot,Off.Sion Trombay Road,Deonar,Mumbai-88.</h6></center>";
			echo "<center><h6>Reimbursement of expenses / Advance Request / Advance Settlement<h6></center>";
				echo "<center><h5>Generate Top-Sheet<h5></center>";
				echo "<div style='overflow-x:auto;'><center><table><tr><th><h4><b>Expenses</b></h4></th><th><h4><b>Amount</b></h4></th></tr>";
			
?>
<html>
<form action="LEVEL3_TOPSHEET_SUBMIT.php" method="post">
<div class="container">
 <div class="form-group">
                    <label for="firstName" class="col-sm-3">For Period:</label>
                    <div class="col-sm-3">
                        <input type="date" id="firstName" required="required" placeholder="Name" class="form-control" name="for_period" autofocus>
                        
           </div>
                    <label for="firstName" class="col-sm-3">To:</label>
                    <div class="col-sm-3">
                        <input type="date" id="firstName" required="required" placeholder="Name" class="form-control" name="to" autofocus>
                            </div>       

                    <label for="firstName" class="col-sm-3">Intervention:</label>
                    <div class="col-sm-3">
					    <select id="level3" class="form-control" name="intervention">
								<option value="KISE">KISE</option>
								<option value="ACCOUNT">ACCOUNT</option>
						</select>
                              </div>     

                    <label for="firstName" class="col-sm-3">Name of School/Center:</label>
                    <div class="col-sm-3">
                        <input type="name" id="firstName" required="required" placeholder="Name of School/Center" class="form-control" name="school" autofocus>
                        
                    </div>
                </div>
</div>
<br>
<?php
$amount1=0;
$user_name = $_SESSION['level3'];
$sql = mysqli_query($conn,"select id from users where `name`='$user_name'");
while($row=mysqli_fetch_array($sql))
{
	$id = $row['id'];
}

$select_query = mysqli_query($conn,"SELECT DISTINCT cat_id FROM post WHERE approved='-2' and user_id='$id' ");
if ($select_query) {
	# code...
	while ($array_catId = mysqli_fetch_array($select_query)) {
		# code...
		$cat_id = $array_catId['cat_id'];
		
	

		$select_amount = mysqli_query($conn,"SELECT SUM(amount) FROM post WHERE cat_id = '$cat_id' AND approved = '-2' and user_id='$id'");
		$select_categoryname=mysqli_query($conn,"SELECT categories_name from categories where categories_id='$cat_id'");
	if ($select_amount) 
	{
		if($select_categoryname)
		{
			# code...
			while ($array_amount = mysqli_fetch_array($select_amount))
			{
					while($array_name = mysqli_fetch_array($select_categoryname)) 
					{
				
				
				# code...
				$categories_name= $array_name['categories_name'];
				$amount = $array_amount['SUM(amount)'];
				echo "<tr><td>$categories_name</td><td>$amount</td></tr>";
				$amount1=$amount1+$amount;
			}
			
			}
		}
	}else{
			echo "Amount Not Fetched";
		}
	}
echo "<tr><td>Total:</td><td>$amount1</td></tr></table><br><br>";

?>

<?php
}
else{
	echo "Category Id Not Fetched";
}
?>

<?php
}
else
{
	echo 'please login';
}
?>               
</center><center><label>&nbsp;&nbsp;&nbsp;<input type='checkbox' id='cbox1' value='Yes' name='bills' required='required'><font color='red'>&nbsp&nbspI am Conforming That All Bills Are Attached.</font></label><br> </h5></center><center>   
 <br><br>
Amount Receivable/payable:
<?php
echo "$amount1";
echo "<input type='hidden' name='amount_receivable' value='$amount1'>";
?><br> 
<br>
Add: Fresh Advance(As per Estimation Attached) Enter having advance :
<input type="text" id="Num1" value="0" name="having_advance" />


<br><br>

Add: Fresh Advance Need an Advance ? Enter Amount &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:
<input type="text" id="Num2" value="0"  name="fresh_advance" />
<br><br><br>Nett Amount Receivable:

<input type="text" id="nett_amount" value="" name="nett_amount" />
<script>

  
    function cal()
    	{
        var balance = parseInt("<?php echo json_encode($amount1); ?>");
        var num1 = parseInt(document.getElementById("Num1").value);
	
	var num2=  parseInt(document.getElementById("Num2").value);
		
	
	document.getElementById("nett_amount").value  =balance-num1+num2;

	}


  

</script><br><br>

<html>
<div class="no-print">
<button type="button" value="cal" onclick="cal()" class='btn btn-primary'>Click me!! To calculate Nett Amount</button>
<button type="button" value="Print" onclick="window.print()" class='btn btn-primary'> print </button>

<button type="button" value="Back" onclick="location.href='LEVEL3_DATA_ENTRY.php'" class='btn btn-primary'>Back</button>

<button type='submit' name='claim'  class='btn btn-primary'>Claim For Expenses</button>


</div>
</form>
</html>