<?php
session_start();
session_destroy();
header('LOCATION:EMPLOYEE_LOGIN.php');
?>