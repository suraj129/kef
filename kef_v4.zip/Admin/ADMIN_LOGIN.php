<?php
session_start();
if(isset($_SESSION['admin']))
{
	header('Location:EMPLOYEE_SIGNUP.php');
}
else
{
?>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
     <link href="css/main.css" rel="stylesheet">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <html>
  <head>
        <title>Admin Login</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <link rel="stylesheet" type="text/css" href="../css/default.css"/>
		<script type="text/javascript" src="../js/script.js"></script>
   <link href="css/main.css" rel="stylesheet">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
  <script src="../js/jquery.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>	


<center><h3>Kotak Education Foundation,Mumbai</h3>
<h4>1st Floor North Side,Silk Mills,Sunder Baug,Opp.Deonar Bus Depot,Off.Sion Trombay Road,Deonar.</h4>
<h4>Mumbai-88.</h4>
<br></center>
	<div class="container">
<body>

<br><br><br><br>
<div class="container">
            <form class="form-horizontal" role="form" action="ADMIN_LOGIN_LOGIC.php" method="post">
							<h1 align="center">Admin Login</h1><br>
                <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Full Name</label>
                    <div class="col-sm-9">
                        <input type="text" id="firstName" placeholder="Name" class="form-control" name="name"autofocus>
                        
                    </div>
                </div>
				<div class="form-group">
                    <label for="password" class="col-sm-3 control-label">Password</label>
                    <div class="col-sm-9">
                        <input type="password" id="password" placeholder="Password" class="form-control" name="password">
                    </div>
				
                 <!-- /form -->
        </div> 
		<div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit" class="btn btn-primary btn-block">Login</button>
                    </div>
                </div>
            </form><!-- ./container -->
			<footer>
			<center>
				<h5> Design by <a href="../contact.html">Trio team</h5><h5></h5>
			</footer>
			</div>
		</body>
		<?php
}
?>
		</html>