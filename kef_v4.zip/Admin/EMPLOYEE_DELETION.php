<?php
include('../dbcon.php');
$id = $_GET["delete"];
$deleteentry = mysqli_query($conn,"delete from post where user_id='$id'");
if($deleteentry)
{
	$deleteuser = mysqli_query($conn,"delete from users where id ='$id'");
	if($deleteuser)
	{
		header('Location:EMPLOYEE_DELETE.php');
	}
}
else
{
	$deleteuser = mysqli_query($conn,"delete from user where id ='$id'");
	if($deleteuser)
	{
		header('Location:EMPLOYEE_DELETE.php');
	}
}

?>