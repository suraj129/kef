<?php


include('../dbcon.php');
session_start();
error_reporting(0);
if(isset($_SESSION['level2']))
{

?>  



 <html>
</head>
    <body>
      
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <link rel="stylesheet" type="text/css" href="../css/default.css"/>
		<script type="text/javascript" src="../js/script.js"></script>
   <link href="css/main.css" rel="stylesheet">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
  <script src="../js/jquery.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>	
     <title>Level1:Display</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <link rel="stylesheet" type="text/css" href="../css/default.css"/>
		<script type="text/javascript" src="../js/script.js"></script>
   <link href="css/main.css" rel="stylesheet">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>	
  <style>
body {
	 
	height:100%;
	font-family: 'Open Sans', sans-serif;
	background: #092756;
	background: -moz-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%),-moz-linear-gradient(top,  rgba(57,173,219,.25) 0%, rgba(42,60,87,.4) 100%), -moz-linear-gradient(-45deg,  #670d10 0%, #092756 100%);
	background: -webkit-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%), -webkit-linear-gradient(top,  rgba(57,173,219,.25) 0%,rgba(42,60,87,.4) 100%), -webkit-linear-gradient(-45deg,  #670d10 0%,#092756 100%);
	background: -o-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%), -o-linear-gradient(top,  rgba(57,173,219,.25) 0%,rgba(42,60,87,.4) 100%), -o-linear-gradient(-45deg,  #670d10 0%,#092756 100%);
	background: -ms-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%), -ms-linear-gradient(top,  rgba(57,173,219,.25) 0%,rgba(42,60,87,.4) 100%), -ms-linear-gradient(-45deg,  #670d10 0%,#092756 100%);
	background: -webkit-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%), linear-gradient(to bottom,  rgba(57,173,219,.25) 0%,rgba(42,60,87,.4) 100%), linear-gradient(135deg,  #670d10 0%,#092756 100%);
	filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#3E1D6D', endColorstr='#092756',GradientType=1 );
}
.navbar{
  background:transparent;
  background-image:none;
  border-color:transparent;
  box-shadow:none;
}
h2,h4,h5,h1,h3,label,b,th,td{ color: #fff; text-shadow: 0 0 10px rgba(0,0,0,0.3); letter-spacing:1px; }

</style>  
    </head>
    <body><nav class="navbar navbar-inverse navbar-fixed-top">
 <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">KEF Accounting System</a>
	<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button></div>
	  <div class="collapse navbar-collapse" id="myNavbar">
		  <ul class="nav navbar-nav">
<li> <a class="" href="#home"></a>
 <li><a href="LEVEL2_DISPLAY.php">Home Screen</a></li>
<li><a href="LEVEL2_CLAIM_EXPENSES.php">Claim Expenses</a></li>
<li><a href="EMPLOYEE_REJECTED_POST.php">Inbox</a></li>
<li><a href="EMPLOYEE_CHANGE_PASSWORD.php">Change Password</a></li>
<li><a href="LEVEL2_TOPSHEET_PRINT.php">Print</a></li>
<li><a href="LEVEL2_DATA_ENTRY.php">Data Entry</a></li>
<li><a href="POST_REJECTED.php">Rejected Post</a></li>
<li><a href="LEVEL2_STATUS_SHEET.php">Status</a></li>
 <li><a href="../contactus.html">Contact Us</a></li>
 <li><a href="../aboutus.html">About Us</a></li>
<li><a href="../LOGOUT.php">Log out</a></li>
</ul>
</div>
  </div>
</nav>

	<div class="container">
</div>
</html>


<?php

$name = $_SESSION['level2'];
$password=$_POST["password"];

$sql = "UPDATE `users` SET `password`='$password' WHERE name='$name'";
$result = mysqli_query($conn, $sql);
if($result)
{

	echo"<br><br><br><h3>Your Password is Changed.</h3><h3>You need To log out.</h3>";
}

else{
	echo "<h3>Your Password is not changed.</h3>";
}
}
else{
echo "please log in..";

}
?>
