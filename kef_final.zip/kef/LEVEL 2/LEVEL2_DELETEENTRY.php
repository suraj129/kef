<?php
include('../dbcon.php');
$id = $_GET["delete"];
 $sql= mysqli_query($conn,"DELETE FROM `post` WHERE id='$id'");
 if($sql)
 {
	 header('Location:LEVEL2_CLAIM_EXPENSES.php');
 }
?>