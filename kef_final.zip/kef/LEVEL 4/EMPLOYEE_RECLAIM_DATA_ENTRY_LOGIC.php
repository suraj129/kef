<?php 
include('../dbcon.php');
session_start();
if(isset($_SESSION['level4'])){
error_reporting(0);
?>
<html>
  <head>
        <title>Employee After Data entry</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <link rel="stylesheet" type="text/css" href="../css/default.css"/>
		<script type="text/javascript" src="../js/script.js"></script>
   <link href="css/main.css" rel="stylesheet">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
  <script src="../js/jquery.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>	
  <style>

body { 

	height:100%;
	font-family: 'Open Sans', sans-serif;
	background: #092756;
	background: -moz-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%),-moz-linear-gradient(top,  rgba(57,173,219,.25) 0%, rgba(42,60,87,.4) 100%), -moz-linear-gradient(-45deg,  #670d10 0%, #092756 100%);
	background: -webkit-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%), -webkit-linear-gradient(top,  rgba(57,173,219,.25) 0%,rgba(42,60,87,.4) 100%), -webkit-linear-gradient(-45deg,  #670d10 0%,#092756 100%);
	background: -o-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%), -o-linear-gradient(top,  rgba(57,173,219,.25) 0%,rgba(42,60,87,.4) 100%), -o-linear-gradient(-45deg,  #670d10 0%,#092756 100%);
	background: -ms-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%), -ms-linear-gradient(top,  rgba(57,173,219,.25) 0%,rgba(42,60,87,.4) 100%), -ms-linear-gradient(-45deg,  #670d10 0%,#092756 100%);
	background: -webkit-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%), linear-gradient(to bottom,  rgba(57,173,219,.25) 0%,rgba(42,60,87,.4) 100%), linear-gradient(135deg,  #670d10 0%,#092756 100%);
	filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#3E1D6D', endColorstr='#092756',GradientType=1 );
}
.navbar{
  background:transparent;
  background-image:none;
  border-color:transparent;
  box-shadow:none;
}
h2,h4,h5,h1,h3,label{ color: #fff; text-shadow: 0 0 10px rgba(0,0,0,0.3); letter-spacing:1px; text-align:center; }


</style>  
    </head>
    <body>
	
<nav class="navbar navbar-inverse navbar-fixed-top">

  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="EMPLOYEE_DATA_ENTRY.php">KEF Accounting System</a>
    
	<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button></div>
	  <div class="collapse navbar-collapse" id="myNavbar">
	  <ul class="nav navbar-nav">
<li> <a class="" href="#home"></a>
 <li><a href="LEVEL4_DISPLAY.php">Home Screen</a></li>
<li><a href="LEVEL4_CLAIM_EXPENSES.php">Claim Expenses</a></li>
<li><a href="EMPLOYEE_REJECTED_POST.php">Inbox</a></li>
<li><a href="EMPLOYEE_CHANGE_PASSWORD.php">Change Password</a></li>
<li><a href="LEVEL4_TOPSHEET_PRINT.php">PRINT</a></li>
<li><a href="LEVEL4_DATA_ENTRY.php">Data Entry</a></li>
<li><a href="POST_REJECTED.php">Rejected Post</a></li>
<li><a href="LEVEL4_STATUS_SHEET.php">Status</a></li>
 <li><a href="../contactus.html">Contact Us</a></li>
 <li><a href="../aboutus.html">About Us</a></li>
<li><a href="../LOGOUT.php">Log out</a></li>
</ul>
  </div>
  </div>
</nav>

<div style="">

</center>
<br><br><hr width='90%'><br> 
	<div class="container">

</html>
<?php
if(isset($_POST)==true && empty($_POST)==false)
{
$name=$_SESSION['level4'];
$claim_date = $_REQUEST['claim_date'];
$date=$_POST['DATE'];
$amount = $_POST['AMOUNT'];
$from = $_POST['FROM'];
$to = $_POST['TO'];
$mode = $_POST['MODE'];
$remark = $_POST['REMARK'];
$categories=$_POST['CATEGORIES'];
$bill = $_POST['bill'];
$user_id=mysqli_query($conn,"select id from users where name='$name'");
if ($user_id) {
	# code...
	while($row=mysqli_fetch_array($user_id))
{
	$user_id1=$row['id'];

	

					
						foreach($to as $a => $b)
						{
						
							$insert_post = mysqli_query($conn,"INSERT INTO `post`(`date`, `amount`, `from`, `to`, `mode`, `remark`, `cat_id`, `bill`, `user_id`,`approved`) VALUES ('$date[$a]','$amount[$a]','$from[$a]','$to[$a]','$mode[$a]','$remark[$a]','$categories[$a]','$bill[$a]','$user_id1','-4')");
						
						}
					
						
}
	
if($insert_post)
{
	$delete_post = mysqli_query($conn,"DELETE from `post` where `approved` = '-1' and `user_id`='$user_id1' and  `claim_date`='$claim_date'");
	if($delete_post)
	{
	header('Location:EMPLOYEE_RECLAIM_EXPENSES.php');
	}
	}

}
}

	?>

	
<?php
}
else
{
	echo 'please login';
}
?>