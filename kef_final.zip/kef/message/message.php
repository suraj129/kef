<html>
  <head>
        <title>Employee Data Entry Form</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <link rel="stylesheet" type="text/css" href="../css/default.css"/>
		<script type="text/javascript" src="../js/script.js"></script>
   <link href="css/main.css" rel="stylesheet">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
  <script src="../js/jquery.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
	
  <style>
body {
    margin: 0;
}
input[type=number]::-webkit-inner-spin-button { 
    -webkit-appearance: none;
    cursor:pointer;
    display:block;
    width:8px;
    color: #333;
    text-align:center;
    position:relative;
}

input[type=number]::-webkit-inner-spin-button:before,
input[type=number]::-webkit-inner-spin-button:after {
    content: "^";
    position:absolute;
    right: 0;
    font-family:monospace;
    line-height:
}

input[type=number]::-webkit-inner-spin-button:before {
    top:0px;
}

input[type=number]::-webkit-inner-spin-button:after {
    bottom:0px;
    -webkit-transform: rotate(180deg);
}

table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    border: 1px solid #ddd;
}

th, td {
    border: none;
    text-align: left;
    padding: 8px;
}
#email1 {
 display: none;
}
tow { display: none; }?
    </head>
    <body>
<nav class="navbar navbar-inverse">

  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">KEF Accounting System</a>
    </div>
<ul class="nav navbar-nav">
<li> <a class="" href="../index.html">HOME</a>

<li><a href="../EMPLOYEE_CHANGE_PASSWORD.php">Change Password</a></li>
<li><a href="../EMPLOYEE/EMPLOYEE_DATA_ENTRY.php">Data Entry</a></li>
<li><a href="../message/email.html">Sent a Alert</a></li>
<li><a href="../LOGOUT.php">Log out</a></li>

</ul>
  </div>
</nav>

<div id="email1">
<center><bold>Send Via Email ID</bold></center>
<center><form action="message_email.php" method="post">
Name: <input type="text" name="name" requird><font color="RED">*</font><br>
E-mail: <input type="text" name="email" requird><font color="RED">*</font><br>
<input type="submit"></center>
</form>
</div>

<div id="number">
    <form action="send_sms.php" method="post">
       <label for="phoneNumber">Phone Number</label>
       <input type="text" name="phoneNumber" id="phoneNumber" placeholder="113456" />
      <label for="carrier">Carrier</label>
       <input type="text" name="carrier" id="carrier" />
       <label for="smsMessage">Message</label>
       <textarea name="smsMessage" id="smsMessage" cols="45" rows="15"></textarea>
     <li><input type="submit" name="sendMessage" id="sendMessage" value="Send Message" />
</form>
  </div>

</div>


</body>
</html>