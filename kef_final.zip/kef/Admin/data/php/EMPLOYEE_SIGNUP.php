<?php
include ('dbcon.php');

$EMPLOYEENAME = $_POST["Employeename"];
$EMPLOYEENO = $_POST["Employeeno"];
$EMPLOYEEMOBILENO = $_POST["Employeemobileno"];
$EMPLOYEE_EMAIL = $_POST["email"];
$EMPLOYEE_PASSWORD = $_POST["Employeepasswd"];


$sql = "INSERT INTO employee_info (employee_name,mobileno,employee_no,employee_email,employee_password) VALUES ('$EMPLOYEENAME','$EMPLOYEEMOBILENO','$EMPLOYEENO','$EMPLOYEE_EMAIL','$EMPLOYEE_PASSWORD')";

if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
	header('Location: loginf1.php');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

?>