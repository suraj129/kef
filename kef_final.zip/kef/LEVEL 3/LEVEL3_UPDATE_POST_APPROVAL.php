<?php

session_start();
if(isset($_SESSION['level3'])){
include('../dbcon.php');
error_reporting(0);
$calculate=$_REQUEST['approved'];
$calculate1 =$_REQUEST['rejected'];
$nett_amount = $_GET['nett_amount'];
$checkby1 = $_GET['checked'];
$name= $_SESSION['level3'];
$claim_date = $_GET['claim_date'];

if($calculate)
{
	$update2=mysqli_query($conn,"UPDATE post SET approved='3',approval2='$name',checkby1='$checkby1' where intervention='ACCOUNT' and   user_id='$calculate' and approved='2' and claim_date='$claim_date'");
	$update=mysqli_query($conn,"UPDATE post SET approved='4',approval3='$name',checkby1='$checkby1' where user_id='$calculate' and approved='2' and claim_date='$claim_date' and intervention='KISE'");
	require '../PHPMailer/PHPMailerAutoload.php';
	$sql = mysqli_query($conn,"select p.level5,u.name from post p,users u where p.user_id='$calculate' and p.user_id=u.id");
	while($row=mysqli_fetch_array($sql))
	{
		$level5 = $row['level5'];
		$user_name = $row['name'];
		$update1=mysqli_query($conn,"select `email` from `users` where `employee no`='$level5'");
		while($row1=mysqli_fetch_array($update1))
		{
			$to = $row1['email'];
		}
	}
$mail = new PHPMailer;

$mail->isSMTP();                                   // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com';                    // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                            // Enable SMTP authentication
$mail->Username = 'donotreply@kotakeducationfoundation.org';          // SMTP username
$mail->Password = 'donotreply@123'; // SMTP password
$mail->SMTPSecure = 'tls';                         // Enable TLS encryption, `ssl` also accepted
$mail->Port = 587;                                 // TCP port to connect to

$mail->setFrom('email@codexworld.com', '');
$mail->addReplyTo('email@codexworld.com', '');
$mail->addAddress($to);   // Add a recipient
//$mail->addCC('cc@example.com');
//$mail->addBCC('bcc@example.com');

$mail->isHTML(true);  // Set email format to HTML

$bodyContent ='Respected Sir/Madam <Br><br><br>Name :'.$user_name.'<br>Has Claimed For reimbursement of expenses / advance settlement of nett amount.<br>Nett Amount Recivable is :'.$nett_amount.'<br>Which Is Approved By  the :'.$name.'<br>Please Kindley Check it in Application.<br>Go to: https://192.168.0.30/kef/<br><br>Thanking You.';
$bodyContent .= '<p>This is the Auto Mailing From The Kotak Education Foundation System Do Not Give Reply';



$mail->Subject = 'Email from Kotak Education Foundation';
$mail->Body    = $bodyContent;

if(!$mail->send()) {
    echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
 
}


}
if($calculate1)
{
$feedback= $_GET['feedback'];
$update1 = mysqli_query($conn,"UPDATE post SET approved='-1',rejected='$feedback',rejectedby='$name' where user_id='$calculate1' and approved='2' and claim_date='$claim_date'");
require '../PHPMailer/PHPMailerAutoload.php';
		$update1=mysqli_query($conn,"select `email` from `users` where `id`='$calculate1'");
		while($row1=mysqli_fetch_array($update1))
		{
			$to1 = $row1['email'];
		}
	
$mail = new PHPMailer;

$mail->isSMTP();                                   // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com';                    // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                            // Enable SMTP authentication
$mail->Username = 'donotreply@kotakeducationfoundation.org';          // SMTP username
$mail->Password = 'donotreply@123'; // SMTP password
$mail->SMTPSecure = 'tls';                         // Enable TLS encryption, `ssl` also accepted
$mail->Port = 587;                                 // TCP port to connect to

$mail->setFrom('email@codexworld.com', '');
$mail->addReplyTo('email@codexworld.com', '');
$mail->addAddress($to1);   // Add a recipient
//$mail->addCC('cc@example.com');
//$mail->addBCC('bcc@example.com');

$mail->isHTML(true);  // Set email format to HTML


$bodyContent ='Name :'.$name.'<br>Has Rejected Expenses.<br>Reason For Rejection is '.$feedback.'<br>Please Kindley Check it .<br>Go to: https://192.168.0.30/kef/';
$bodyContent .= '<p>This is the Auto Mailing From The Kotak Education Foundation System Do Not Give Reply';

$mail->Subject = 'Email from Kotak Education Foundation';
$mail->Body    = $bodyContent;

if(!$mail->send()) {
    echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
	
}

}
?>

<html>
  <html>
<head>        <title>Level 3:post approval</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <link rel="stylesheet" type="text/css" href="../css/default.css"/>
		<script type="text/javascript" src="../js/script.js"></script>
   <link href="css/main.css" rel="stylesheet">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>	
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
  <script src="../js/jquery.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>	
<style>
 body {
	 
	height:100%;
	font-family: 'Open Sans', sans-serif;
	background: #092756;
	background: -moz-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%),-moz-linear-gradient(top,  rgba(57,173,219,.25) 0%, rgba(42,60,87,.4) 100%), -moz-linear-gradient(-45deg,  #670d10 0%, #092756 100%);
	background: -webkit-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%), -webkit-linear-gradient(top,  rgba(57,173,219,.25) 0%,rgba(42,60,87,.4) 100%), -webkit-linear-gradient(-45deg,  #670d10 0%,#092756 100%);
	background: -o-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%), -o-linear-gradient(top,  rgba(57,173,219,.25) 0%,rgba(42,60,87,.4) 100%), -o-linear-gradient(-45deg,  #670d10 0%,#092756 100%);
	background: -ms-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%), -ms-linear-gradient(top,  rgba(57,173,219,.25) 0%,rgba(42,60,87,.4) 100%), -ms-linear-gradient(-45deg,  #670d10 0%,#092756 100%);
	background: -webkit-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%), linear-gradient(to bottom,  rgba(57,173,219,.25) 0%,rgba(42,60,87,.4) 100%), linear-gradient(135deg,  #670d10 0%,#092756 100%);
	filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#3E1D6D', endColorstr='#092756',GradientType=1 );
}
.navbar{
  background:transparent;
  background-image:none;
  border-color:transparent;
  box-shadow:none;
}
h2,h4,h5,h1,h3,label{ color: #fff; text-shadow: 0 0 10px rgba(0,0,0,0.3); letter-spacing:1px; 
</style>  
    </head>
    <body>
<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">KEF Accounting System</a>
	<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button></div>
	  <div class="collapse navbar-collapse" id="myNavbar">
	  <ul class="nav navbar-nav">
<li> <a class="" href="#home"></a>
 <li><a href="LEVEL3_DISPLAY.php">Home Screen</a></li>
<li><a href="LEVEL3_CLAIM_EXPENSES.php">Claim Expenses</a></li>
<li><a href="LEVEL3_REJECTED_POST.php">Inbox</a></li>
<li><a href="../EMPLOYEE_CHANGE_PASSWORD.php">Change Password</a></li>
<li><a href="LEVEL3_TOPSHEET_PRINT.php">PRINT</a></li>
<li><a href="LEVEL3_DATA_ENTRY.php">Data Entry</a></li>
<li><a href="POST_REJECTED.php">Rejected Post</a></li>
 <li><a href="../contactus.html">Contact Us</a></li>
 <li><a href="../aboutus.html">About Us</a></li>
<li><a href="../LOGOUT.php">Log out</a></li>
</ul>
  </div>
  </div>
</nav>

<div style="margin-left:18%;padding:1px 0px;height:1000px;">

<br><br><hr width="90%">
	<div class="container">
<?php	
if($calculate)
{
	echo"<h3>You have approved the Expenses</h3>";
	 echo "<h3>Mail Has Been Sent To Above Level.</h3>";
	 echo "<form action='LEVEL3_MAIL_SENT.php' method='get'>
					<input type='hidden' value='$calculate' name='id'>
					<button type='submit' value='$claim_date' name='claim_date' class='btn btn-primary'>Sent mail To Employee</button>";
}
if($calculate1)
{
	echo"<h3>You have Rejected the Expenses</h3>";
    echo "<h3>Mail Has Been Sent To Employee.</h3>";
}
	
}
else{
echo 'please log in..';

}
?>

<button type="button" value="Mail" onclick="location.href='LEVEL3_DISPLAY.php'" class='btn btn-primary'>back</button>
</html>
