   <html>
         <title>Employee :Topsheet submit</title>
       <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <link rel="stylesheet" type="text/css" href="../css/default.css"/>
		<script type="text/javascript" src="../js/script.js"></script>
   <link href="css/main.css" rel="stylesheet">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
  <script src="../js/jquery.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>	
  <style>
body {
    margin: 0;
}
input[type=number]::-webkit-inner-spin-button { 
    -webkit-appearance: none;
    cursor:pointer;
    display:block;
    width:8px;
    color: #333;
    text-align:center;
    position:relative;
}

input[type=number]::-webkit-inner-spin-button:before,
input[type=number]::-webkit-inner-spin-button:after {
    content: "^";
    position:absolute;
    right: 0;
    font-family:monospace;
    line-height:
}

input[type=number]::-webkit-inner-spin-button:before {
    top:0px;
}

input[type=number]::-webkit-inner-spin-button:after {
    bottom:0px;
    -webkit-transform: rotate(180deg);
}

table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    border: 1px solid #ddd;
}

th, td {
    border: none;
    text-align: left;
    padding: 8px;
}

</style>  
    </head>
    <body>
<nav class="navbar navbar-inverse">

  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">KEF Accounting System</a>
    </div>
<ul class="nav navbar-nav">
<li> <a class="active" href="#home"></a>
 <li><a href="EMPLOYEE_DATA_ENTRY">Home Screen</a></li>
<li><a href="EMPLOYEE_CLAIM_EXPENSES.php">Claim Expenses</a></li>
<li><a href="EMPLOYEE_REJECTED_POST.php">Inbox</a></li>
<li><a href="../EMPLOYEE_CHANGE_PASSWORD.php">Change Password</a></li>
<li><a href="/EMPLOYEE_DATA_ENTRY.php">Data Entry</a></li>
<li><a href="../LOGOUT.php">Log out</a></li>
</ul>
  </div>
</nav>



<div style="margin-left:22%;padding:1px 0px;height:1000px;">
	
<div class="container">
<?php
include('../dbcon.php');
session_start();
if(isset($_SESSION['employee']))
{
$username= $_SESSION['employee'];
$getid= mysqli_query($conn,"select id from users where name='$username'");
$getlevel= mysqli_query($conn,"select `stlevel`,`level1`,`level2`,`level3`,`level4`,`level5`,`employee no` from `users` where `name`='$username'");
if($getid)
{
while($row = mysqli_fetch_array($getid))
{
	$id=$row['id'];
}
}
if($getlevel)
{
while($row = mysqli_fetch_array($getlevel))
{
	$stlevel=$row['stlevel'];
	$level1 = $row['level1'];
	$level2 = $row['level2'];
	$level3 = $row['level3'];
	$level4 = $row['level4'];
	$level5 = $row['level5'];
	$employeeno = $row['employee no'];
}
}
$bills=$_POST["bills"];
$for_period= $_POST["for_period"];
$to=$_POST["to"];
$intervention = $_POST["intervention"];
$school= $_POST["school"];
$amount_receivable=$_POST["amount_receivable"];
$fresh_advance=$_POST["fresh_advance"];
$nett_amount= $_POST["nett_amount"];
$having_advance=$_POST["having_advance"];
$update=mysqli_query($conn,"UPDATE `post` SET `claim_date`=now(),`for period`='$for_period',`Too`='$to',`intervention`='$intervention',`name of school/center`='$school',`amount recivable/payable`='$amount_receivable',`having advance`='$having_advance',`fresh advance`='$fresh_advance',`nett amount receivable`='$nett_amount',`approved`='$stlevel',`level1`='$level1',`level2`='$level2',`level3`='$level3',`level4`='$level4',`level5`='$level5',`empbillcheck`='$bills' WHERE `approved`=-4 and `user_id`='$id'");}
if($update)
{
header('Location:email.php');
}
}
else
{
	echo "Login First ";
}
?>
</div>
</html>
