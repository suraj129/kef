<?php
session_start();
if(isset($_SESSION['employee'])){
?>
<html>
  <head>
        <title>EMPLOYEE : REJECTED</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <link rel="stylesheet" type="text/css" href="../css/default.css"/>
		<script type="text/javascript" src="../js/script.js"></script>
   <link href="css/main.css" rel="stylesheet">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
  <script src="../js/jquery.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>	
<style>
 body {
	 height: 200%;
	font-family: 'Open Sans', sans-serif;
	background: #092756;
	background: -moz-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%),-moz-linear-gradient(top,  rgba(57,173,219,.25) 0%, rgba(42,60,87,.4) 100%), -moz-linear-gradient(-45deg,  #670d10 0%, #092756 100%);
	background: -webkit-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%), -webkit-linear-gradient(top,  rgba(57,173,219,.25) 0%,rgba(42,60,87,.4) 100%), -webkit-linear-gradient(-45deg,  #670d10 0%,#092756 100%);
	background: -o-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%), -o-linear-gradient(top,  rgba(57,173,219,.25) 0%,rgba(42,60,87,.4) 100%), -o-linear-gradient(-45deg,  #670d10 0%,#092756 100%);
	background: -ms-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%), -ms-linear-gradient(top,  rgba(57,173,219,.25) 0%,rgba(42,60,87,.4) 100%), -ms-linear-gradient(-45deg,  #670d10 0%,#092756 100%);
	background: -webkit-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%), linear-gradient(to bottom,  rgba(57,173,219,.25) 0%,rgba(42,60,87,.4) 100%), linear-gradient(135deg,  #670d10 0%,#092756 100%);
	filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#3E1D6D', endColorstr='#092756',GradientType=1 );
}
.navbar{
  background:transparent;
  background-image:none;
  border-color:transparent;
  box-shadow:none;
}
h2,h4,h5,h1,h3,label,b{ color: #fff; text-shadow: 0 0 10px rgba(0,0,0,0.3); letter-spacing:1px; }

 td {
   border: 1px solid black;
   padding: 5px;
   text-align: left;
   font-size: 100%;
   color: #fff ;
    font-weight: bold;
}
table {
    width: 90%;
    border-collapse: collapse;
     font-size: 100%;
    #f5f5f5;
}

th {
    font-size: 15px;
    height: 15px;
    text-align: left;
    border: 1px solid black;
 font-size: 100%;
 color: #fff ;

 }
@media print
{
    #pager,
    form,
    .no-print
    {
        display: none !important;
        height: 0;
    }


    .no-print, .no-print *{
        display: none !important;
        height: 0;
    }
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>
</head>

<nav class="navbar navbar-inverse navbar-fixed-top">

  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="EMPLOYEE_DATA_ENTRY.php">KEF Accounting System</a>
    
	<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button></div>
	  <div class="collapse navbar-collapse" id="myNavbar">
<ul class="nav navbar-nav">
<li> <a class="active" href="#home"></a></li>
 <li><a href="EMPLOYEE_DATA_ENTRY.php">Home Screen</a></li>
<li><a href="EMPLOYEE_CLAIM_EXPENSES.php">Claim Expenses</a></li>
<li><a href="EMPLOYEE_REJECTED_POST.php">Inbox</a></li>
<li><a href="../EMPLOYEE_CHANGE_PASSWORD.php">Change Password</a></li>
<li><a href="EMPLOYEE_DATA_ENTRY.php">Data Entry</a></li>
<li><a href="EMPLOYEE_TOPSHEET_PRINT.php">Print</a></li>
 <li><a href="../contactus.html">Contact Us</a></li>
 <li><a href="../aboutus.html">About Us</a></li>
<li><a href="../LOGOUT.php">Log out</a></li>
</ul>
  </div>
  </div>
</nav>
<br>
<body>
<div style=""><br><br>
<hr width="90%">
	<div class="container">
	<form action ="EMPLOYEE_RECLAIM_DATA_ENTRY_LOGIC.php" method="post">
	<fieldset class="row1">

	<h3>Details of Expenses</h3>
				
 <table id="dataTable" class="table table-sm" border="0">
   <tbody>
<?php
include('../dbcon.php');
$username = $_SESSION['employee'];
$claim_date = $_REQUEST['claim_date'];
$getname = mysqli_query($conn,"SELECT DISTINCT `id`, `employee no` FROM `users` WHERE `name`='$username'");
	if($getname)
				{
					while($row=mysqli_fetch_array($getname))
					{
						$id=$row['id'];
						$employeeno	=	$row['employee no'];
					}
				}
$get_data = mysqli_query($conn,"select * from `post` where `user_id`='$id' and `claim_date`='$claim_date' and `approved`='-1'");
while($row = mysqli_fetch_array($get_data))
{
	$date = $row['date'];
	$from = $row['from'];
	$to = $row['to'];
	$amount = $row['amount'];
	$mode = $row['mode'];
	$remark = $row['remark'];
	$cat_id = $row['cat_id'];
	$bill = $row['bill'];
	
	$get_categoryname = mysqli_query($conn,"select * from categories where categories_id='$cat_id'");
	while($row2 = mysqli_fetch_array($get_categoryname))
	{
		$categories_name = $row2['categories_name'];
	}

?>
 <tr><td><font color="red">*</font>
					  <label for="name">Date:</label>
					  <font color="black">
    					      <input type="date" name="DATE[]" value='<?php echo "$date" ;?>'></input> 	
                 </td>
						</td>
						<td><font color="red">*</font>
							<label>Amount:</label>
							<font color="black">
							<input type="number" required="required" name="AMOUNT[]" value='<?php echo "$amount" ;?>'>
							</font></input>
						 </td>
						 <td>
							<label for="BX_age">From</label>
							<font color="black">
							<input type="text"  name="FROM[]" value='<?php echo "$from" ;?>'>
					     </td>
						 <td>
							<label for="BX_age">To:</label>
							<font color="black">
							<input type="text"   name="TO[]" value='<?php echo "$to" ;?>'>
					     </td>
						 <td>
							<label for="BX_age">Mode</label>
							<font color="black">
							<select id="MODE"    name="MODE[]">
								<option value=<?php echo "$mode" ;?>><?php echo "$mode"?></option>
								<option value="Empty">Empty</option>
								<option value="Auto">Auto</option>
								<option value="Auto">Taxi</option>
								<option  value="Share Auto">Share Auto</option>
								<option value="Share Taxi">Share TAXI</option>
								<option value="Bus">Bus</option>
						
								<option value="Train">Train</option>
							
							</select>
					     </td>
						 <td>
							<label for="BX_age">Remark:</label>
							<font color="black">
							<input type="text"    name="REMARK[]" value='<?php echo "$remark" ;?>'>
					     </td>
						 <td><font color="red">*</font>
							<label for="BX_expanses">Categories</label><br>
							<font color="black">
							<select id="BX_expanses" name="CATEGORIES[]" required>
							    <option value=<?php echo "$cat_id" ;?>><?php echo "$categories_name"?></option>
								<option value="1">Conveyance Expenses</option>
								<option  value="2">Inconvenince Expenses</option>
								<option value="3">Refreshment charges</option>
								<option value="4">Repair and maintenance Charges</option>
								<option value="5">Housekeeping material</option>
								<option value="6">Housekeeping Wages</option>
								<option value="7">Advertisement expenses</option>
								<option value="8">Printing and stationery Expenses</option>
								<option value="9"> Reimb. Medical Expenses(Salary-Monthly Expenses)</option>
								<option value="10">Photo Expenses</option>
								<option value="11">Honorarium Given</option>
								<option value="12">Internet Expenses</option>
								<option value="13">Electricity Charges</option>
								<option value="14">Hire Charges</option>
								<option value="15">Flower Expenses</option>
								<option value="16">Telephone Expenses</option>
								<option value="17">Postage & Courier Expenses</option>
								<option value="18">Gifts Expenses</option>
								<option value="19">Miscellaneous </option>
							</select>
						 </td>
						  <td><font color="red">*</font>
							<label for="Bil">Bill ? </label><br>
							<font color="black">
							<select id="BX_expanses" name="bill[]" required>
							 <option value=<?php echo "$bill" ;?>><?php echo "$bill"?></option>
							<option  value="No">No</option>
							<option value="Yes">Yes</option>
								
						</select>
                    </tr>
                 
			


<?php
}
?>	  
 </tbody>
                </table>
	<div class="clear"></div>
				<br>
            </fieldset>
			<div align="left">
				<p> <input type="hidden" name="claim_date" value="<?php echo htmlspecialchars($claim_date); ?>">
					
			<input type="submit" value="Save Expenses" class="btn btn-primary"/>
			</p>
			</form>
			<div>
			</div>
<?php
}
else
{
	echo "Login First";
}
?>