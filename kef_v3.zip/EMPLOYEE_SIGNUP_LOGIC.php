<?php
include('dbcon.php');
$name=$_POST["name"];
$password=$_POST["password"];
$phone=$_POST["phone"];
$email=$_POST["email"];
$role=$_POST["role"];
$levels=$_POST["levels"];
$employeeno = $_POST["employeeno"];
$levels = implode(',',$_POST['levels']);

$insert_record="INSERT INTO `users`(`id`,`name`,`employee no`, `password`, `phone`, `email`, `role_id`,`levels`) VALUES ('','$name','$employeeno','$password','$phone','$email','$role','$levels')";

if (mysqli_query($conn, $insert_record)) {
	echo "<center><h3>New Employee Account is Created.</a></h3></center>";
		
} else {
    echo "Error: " . $insert_record . "<br>" . mysqli_error($conn);	
		
}

?>
<html>
<style>

a:link, a:visited {
    background-color: #f44336;
    color: white;
    padding: 14px 25px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
}


a:hover, a:active {
    background-color: red;
}
</style>

<center><a href="EMPLOYEE_SIGNUP.php">DONE</a>
</center>
</html>