<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kef_accounting";



$employee_email = $_POST["email"];
$employee_passwd = $_POST["passwd"];

$conn = mysqli_connect($servername, $username, $password, $dbname);

$sql = "SELECT employee_email, employee_password FROM employee_info WHERE email = '".$employee_email."' AND password = '".$employee_passwd."'";
$result = mysqli_query($conn,$sql);

if (mysqli_num_rows($result)>0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        if($email == $row["email"] and $passwd == $row["password"]){
			$_SESSION['name']=$email;
			echo "Logged in";
			
		}
		else {
			echo "Wrong";
			
		}
    }
	
} else
{
    
}

mysqli_close($conn);
?>