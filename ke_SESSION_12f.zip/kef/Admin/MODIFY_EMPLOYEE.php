<?php
session_start();
if(isset($_SESSION['admin']))
{
?>
<head>
        <title>Admin : Emoloyee Modify</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <link rel="stylesheet" type="text/css" href="../css/default.css"/>
		<script type="text/javascript" src="../js/script.js"></script>
   <link href="css/main.css" rel="stylesheet">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
  <script src="../js/jquery.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>	


        
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>	
  <style>
body {
    margin: 0;
}


</style>  
    </head>
    <body>

<nav class="navbar navbar-inverse">

  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">KEF Accounting System</a>
    </div>
<ul class="nav navbar-nav">
<li> <a class="active" href="#home"></a>
 <li><a href="EMPLOYEE_SIGNUP.php">Home Screen</a></li>
<li><a href="EMPLOYEE_DELETE.php">Delete Employee</a></li>
<li><a href="../message/email.html">Sent a Alert</a></li>
<li><a href="MODIFY_EMPLOYEE.php">Modify Employee</a></li>
<li><a href="ADMIN_LOGOUT.php">Log out</a></li>
</ul>
  </div>
</nav>
     <link href="css/main.css" rel="stylesheet">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>

<body>
<br>
<div class="container">
            <form class="form-horizontal" role="form" action="MODIFY_EMPLOYEE_LOGIC.php" method="post">
                <h1><center>Employee Modification</h1><br>
				<?php
				$i=0;
				
				include('../dbcon.php');
				$users=mysqli_query($conn,'SELECT name,id FROM users');
				
				if($users)
				{
					echo "<div style='overflow-x:auto;'><center><table><tr><th><h4><b>&nbspSr no.</b></h4></th><th><h4><b>&nbspName</b></h4></th><th><h4><b>&nbsp&nbsp&nbsp&nbsp&nbspMoidfy</b></h4></th></tr>";
					while($users_name=mysqli_fetch_array($users))
					{
						$user = $users_name['name'];
						$id = $users_name['id'];
						$i++;
						echo "<tr><td><h4>&nbsp$i</h4></td><td><h4>$user</h4></td><td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<center><form action='MODIFY_EMPLOYEE_LOGIC.php' method='GET'><button type='submit' name='modify' value='$id' class='btn btn-primary'>Modify Employee</button></center></form></td></tr>";
					}
						echo "</table>";
				}
				?>
		
			<footer>
			<center>
			<h5> Design by Trio team</h5>
			</footer>
		</body>






<?php
}
else
{
	echo "please Login first";
}
?>